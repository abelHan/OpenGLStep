Thank you for submitting a pull request, it's much appreciated.

Because this is a mirror repo, we may not respond to or merge the PR in the timely manner you may expect.

One way to get more attention to your issue is to message our mailing list: `freeglut-developer at lists.sourceforge.net`